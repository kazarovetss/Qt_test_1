#include <QGraphicsPixmapItem>
#include <QMimeData>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QDataStream>
#include "mygraphicsview.h"

QListWidget *globalListWidget;

MyGraphicsView::MyGraphicsView(QWidget *parent) : QGraphicsView(parent) {}

void MyGraphicsView::dragEnterEvent(QDragEnterEvent *event) {
    if (event->mimeData()->hasFormat("application/vnd.text.listwidgetitem")) {
        event->acceptProposedAction();
    }
}

void MyGraphicsView::dragMoveEvent(QDragMoveEvent *event) {
    if (event->mimeData()->hasFormat("application/vnd.text.listwidgetitem")) {
        event->acceptProposedAction();
    }
}

void MyGraphicsView::dropEvent(QDropEvent *event) {
    if (event->mimeData()->hasFormat("application/vnd.text.listwidgetitem")) {
        QByteArray itemData = event->mimeData()->data("application/vnd.text.listwidgetitem");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        QPixmap pixmap;
        QString text;
        dataStream >> pixmap >> text;
        scene()->setSceneRect(0, 0, this->width()-5, this->height()-5);

        const int itemWidth = 64;
        const int itemHeight = 64;
        const int itemsPerRow = this->width() / itemWidth;
        int itemCount = this->scene()->items().count();

        int x = (itemCount % itemsPerRow) * itemWidth;
        int y = (itemCount / itemsPerRow) * itemHeight;

        QGraphicsPixmapItem *item = new QGraphicsPixmapItem(pixmap);
        item->setFlag(QGraphicsItem::ItemIsSelectable, true);
        item->setData(0, text);
        item->setPos(x,y);
        scene()->addItem(item);

        event->acceptProposedAction();

    }
}


