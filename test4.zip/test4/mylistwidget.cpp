#include "mylistwidget.h"


MyListWidget::MyListWidget(QWidget *parent) : QListWidget(parent) {
    setDragEnabled(true);
    setAcceptDrops(true);
    setDropIndicatorShown(true);
    addIconsWithLabels();
}

void MyListWidget::addIconsWithLabels()
{
    QListWidgetItem *item1 = new QListWidgetItem(QIcon("C:/Users/37533/Documents/build-test4-Desktop_Qt_6_6_1_MinGW_64_bit-Debug/color/green.jpg"), "Зеленый");
    this->addItem(item1);

    QListWidgetItem *item2 = new QListWidgetItem(QIcon("C:/Users/37533/Documents/build-test4-Desktop_Qt_6_6_1_MinGW_64_bit-Debug/color/red.jpg"), "Красный");
    this->addItem(item2);

    QListWidgetItem *item3 = new QListWidgetItem(QIcon("C:/Users/37533/Documents/build-test4-Desktop_Qt_6_6_1_MinGW_64_bit-Debug/color/orange.jpg"), "Оранжевый");
    this->addItem(item3);

    QListWidgetItem *item4 = new QListWidgetItem(QIcon("C:/Users/37533/Documents/build-test4-Desktop_Qt_6_6_1_MinGW_64_bit-Debug/color/blue.png"), "Синий");
    this->addItem(item4);

    QListWidgetItem *item5 = new QListWidgetItem(QIcon("C:/Users/37533/Documents/build-test4-Desktop_Qt_6_6_1_MinGW_64_bit-Debug/color/yellow.png"), "Желтый");
    this->addItem(item5);
}


void MyListWidget::mousePressEvent(QMouseEvent *event) {
    QListWidget::mousePressEvent(event);

    if (event->button() != Qt::LeftButton) return;

    QListWidgetItem *item = itemAt(event->pos());
    if (!item) return;

    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);
    QPixmap pixmap = item->icon().pixmap(32, 32);
    QString text = item->text();
    dataStream << pixmap << text;

    QMimeData *mimeData = new QMimeData;
    mimeData->setData("application/vnd.text.listwidgetitem", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);
    drag->setPixmap(pixmap);
    drag->setHotSpot(QPoint(0, 0));
    drag->exec(Qt::CopyAction | Qt::MoveAction);
}


