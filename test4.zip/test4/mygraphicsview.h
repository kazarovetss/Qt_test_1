#ifndef MYGRAPHICSVIEW_H
#define MYGRAPHICSVIEW_H

#include <QListWidget>
#include <QMimeData>
#include <QDrag>
#include <QMouseEvent>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QGraphicsView>
#include "mylistwidget.h"

extern QListWidget *globalListWidget;

class MyGraphicsView : public QGraphicsView {

public:
    explicit MyGraphicsView(QWidget *parent = nullptr);

protected:
    void dragEnterEvent(QDragEnterEvent *event);
    void dragMoveEvent(QDragMoveEvent *event);
    void dropEvent(QDropEvent *event);
};

#endif
