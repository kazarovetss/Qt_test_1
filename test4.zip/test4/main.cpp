#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QListView>
#include <QTableView>
#include "MyListWidget.h"
#include "mygraphicsview.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QWidget window;
    window.setWindowTitle("Комплексное расположение виджетов");

    QHBoxLayout *mainLayout = new QHBoxLayout;

    QVBoxLayout *leftLayout = new QVBoxLayout;
    QGraphicsScene *graphicsScene = new QGraphicsScene();
    MyGraphicsView *graphicsView = new MyGraphicsView();
    graphicsView->setScene(graphicsScene);
    graphicsView->setAcceptDrops(true);
    leftLayout->addWidget(graphicsView, 1);


    QHBoxLayout *bottomLayout = new QHBoxLayout;
    QListView *listView = new QListView;
    QTableView *tableView = new QTableView;
    bottomLayout->addWidget(tableView);
    bottomLayout->addWidget(listView);
    leftLayout->addLayout(bottomLayout);

    QGroupBox *groupBox = new QGroupBox("Элементы управления");
    groupBox->setFixedWidth(200);
    QVBoxLayout *groupBoxLayout = new QVBoxLayout(groupBox);
    MyListWidget *myListWidget = new MyListWidget;
    groupBoxLayout->addWidget(myListWidget, 0);


    mainLayout->addLayout(leftLayout, 2);
    mainLayout->addWidget(groupBox, 1);

    window.setLayout(mainLayout);
    window.resize(800, 600);
    window.show();

    return app.exec();
}
